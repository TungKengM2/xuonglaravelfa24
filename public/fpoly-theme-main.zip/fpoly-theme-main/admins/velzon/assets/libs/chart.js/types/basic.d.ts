
export type AnyObject = Record<string, any>;
export type EmptyObject = Record<string, never>;
